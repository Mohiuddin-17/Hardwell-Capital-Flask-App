import tabula
import os
from pathlib import Path

# --- Configuration ---
PDF_PATH = "RentRoll02_24_2021 Autumn.pdf"
OUTPUT_CSV = "Rent_Roll_Autumn_output_clean.csv"

# Optional: set Java path if needed
java_path = r"C:\Program Files\Java\jdk-11"
if os.path.exists(java_path):
    os.environ["JAVA_HOME"] = java_path

# --- Function ---
def convert_t12_pdf_to_csv(pdf_path, output_csv):
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        print(f"❌ File not found: {pdf_path}")
        return

    try:
        print(f"📄 Converting T12 PDF: {pdf_path.name}")
        tabula.convert_into(
            input_path=str(pdf_path),
            output_path=output_csv,
            output_format="csv",
            pages="all",
            guess=True,       # Let Tabula detect tables freely
            lattice=False     # Change to True if you need tighter table detection
        )
        print(f"✅ Success! Output saved to: {output_csv}")
    except Exception as e:
        print(f"❌ Conversion failed: {str(e)}")

# --- Run ---
if __name__ == "__main__":
    convert_t12_pdf_to_csv(PDF_PATH, OUTPUT_CSV)
