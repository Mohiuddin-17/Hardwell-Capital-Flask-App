import tabula
import os

# Java path for Tabula
java_path = r"C:\Program Files\Java\jdk-11\bin\server\jvm.dll"
if os.path.exists(java_path):
    os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-11"

tabula.convert_into("T12_3350_Mount_Gilead_Rd_Atlanta_GA_30311.pdf", "check_output.csv", output_format="csv", pages="all", guess=True)


