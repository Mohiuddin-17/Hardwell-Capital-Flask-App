# pdf_generator.py

import logging
import os
from typing import Dict, Any
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

logger = logging.getLogger(__name__)


# -------------------------
# Helpers
# -------------------------
def safe_get(data: Dict[str, Any], keys, default="N/A"):
    """
    Safely retrieve nested dictionary values.
    keys may be a single key (str) or a list/tuple of keys for nested lookup.
    """
    if not isinstance(keys, (list, tuple)):
        keys = [keys]
    current = data
    for key in keys:
        if not isinstance(current, dict):
            return default
        current = current.get(key, default)
    return current


def clean_text(text: Any) -> str:
    """
    Convert to string and sanitize common unicode characters so the PDF build won't fail.
    Non-latin1 characters will be replaced.
    """
    if text is None:
        text = ""
    if not isinstance(text, str):
        text = str(text)

    replacements = {
        '\u2022': '-',   # bullet → dash
        '\u2013': '-',   # en dash → dash
        '\u2014': '-',   # em dash → dash
        '\u2018': "'",   # left single quote → '
        '\u2019': "'",   # right single quote → '
        '\u201C': '"',   # left double quote → "
        '\u201D': '"',   # right double quote → "
        '\u2026': '...', # ellipsis
    }
    for bad, good in replacements.items():
        text = text.replace(bad, good)

    # Final fallback: replace any remaining non-Latin1 chars with '?'
    return text.encode('latin-1', errors='replace').decode('latin-1')


def format_currency(val: Any) -> str:
    try:
        return f"${float(val):,.2f}"
    except Exception:
        return clean_text(val)


def format_percent(val: Any) -> str:
    try:
        return f"{float(val) * 100:.1f}%" if (0 < float(val) < 10) else f"{float(val):.1f}%" if float(val) >= 10 else f"{float(val):.1f}%"
    except Exception:
        return clean_text(val)


def format_int(val: Any) -> str:
    try:
        return str(int(float(val)))
    except Exception:
        return clean_text(val)


def safe_float(val: Any, default: float = 0.0) -> float:
    """Safely convert a value to float, returning default if conversion fails."""
    try:
        return float(val)
    except (ValueError, TypeError):
        return default


# -------------------------
# Main safe generator
# -------------------------
def generate_safe_pdf_report(data: Dict[str, Any]) -> str:
    """
    Generates a PDF report that won't crash on bad/missing data.
    Returns the filename (not full path).
    """
    output_dir = os.environ.get("OUTPUT_FOLDER", "outputs")
    os.makedirs(output_dir, exist_ok=True)
    filename = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    filepath = os.path.join(output_dir, filename)

    styles = getSampleStyleSheet()
    story = []

    # --- Title ---
    story.append(Paragraph(clean_text("Underwriting Report"), styles["Title"]))
    story.append(Spacer(1, 12))

    # --- Property Summary (restored) ---
    story.append(Paragraph("Property Summary", styles["Heading2"]))
    prop_info = safe_get(data, ['property_info'], {})

    # prefer property_info fields but fall back to top-level keys if present
    prop_name = clean_text(safe_get(data, ['property_info', 'name'], safe_get(data, 'property_name', 'N/A')))
    prop_address = clean_text(safe_get(data, ['property_info', 'address'], safe_get(data, 'property_address', 'N/A')))
    prop_city = clean_text(safe_get(data, ['property_info', 'city'], safe_get(data, 'city', 'N/A')))
    prop_state = clean_text(safe_get(data, ['property_info', 'state'], safe_get(data, 'state', 'N/A')))
    prop_zip = clean_text(safe_get(data, ['property_info', 'zip'], safe_get(data, 'zip', 'N/A')))

    total_units = safe_get(data, ['property_info', 'units'], safe_get(data, 'total_units', 'N/A'))
    occupied_units = safe_get(data, ['property_info', 'occupied_units'], safe_get(data, 'occupied_units', 'N/A'))

    # occupancy rate: try to compute if both units available
    occupancy_rate_raw = safe_get(data, ['property_info', 'occupancy_rate'], safe_get(data, 'occupancy_rate', None))
    if occupancy_rate_raw in (None, 'N/A'):
        try:
            total_u = int(float(total_units))
            occ_u = int(float(occupied_units))
            occupancy_rate = f"{(occ_u / total_u * 100):.1f}%" if total_u > 0 else "N/A"
        except Exception:
            occupancy_rate = "N/A"
    else:
        occupancy_rate = format_percent(occupancy_rate_raw) if isinstance(occupancy_rate_raw, (int, float)) else clean_text(occupancy_rate_raw)

    story.append(Paragraph(f"<b>Name:</b> {prop_name}", styles["Normal"]))
    story.append(Paragraph(f"<b>Address:</b> {prop_address}", styles["Normal"]))
    story.append(Paragraph(f"<b>Total Units:</b> {format_int(total_units)}", styles["Normal"]))
    story.append(Paragraph(f"<b>Occupied Units:</b> {format_int(occupied_units)}", styles["Normal"]))
    story.append(Paragraph(f"<b>Occupancy Rate:</b> {clean_text(occupancy_rate)}", styles["Normal"]))
    story.append(Spacer(1, 12))

    # --- Financial Summary (restored) ---
    story.append(Paragraph("Financial Summary", styles["Heading2"]))

    # Try multiple possible keys for common financial fields
    gpi = safe_get(data, ['income', 'gross_potential_income'], safe_get(data, 'gross_potential_rent', 0))
    egi = safe_get(data, ['income', 'effective_gross_income'], safe_get(data, 'effective_gross_income', 0))
    noi = safe_get(data, ['net_operating_income'], safe_get(data, ['income', 'net_operating_income'], safe_get(data, 'net_operating_income', 0)))
    expenses_total = safe_get(data, 'total_operating_expenses', safe_get(data, ['expense_summary', 'total_expenses'], 0))
    cap_rate_used = safe_get(data, 'cap_rate_used', safe_get(data, ['financials', 'cap_rate_used'], 0))
    property_value = safe_get(data, 'property_value', safe_get(data, ['financials', 'property_value'], 0))

    story.append(Paragraph(f"<b>Gross Potential Income:</b> {format_currency(gpi)}", styles["Normal"]))
    story.append(Paragraph(f"<b>Effective Gross Income:</b> {format_currency(egi)}", styles["Normal"]))
    story.append(Paragraph(f"<b>Total Operating Expenses:</b> {format_currency(expenses_total)}", styles["Normal"]))
    story.append(Paragraph(f"<b>Net Operating Income (NOI):</b> {format_currency(noi)}", styles["Normal"]))
    story.append(Paragraph(f"<b>Cap Rate Used:</b> {format_percent(cap_rate_used)}", styles["Normal"]))
    story.append(Paragraph(f"<b>Property Value:</b> {format_currency(property_value)}", styles["Normal"]))
    story.append(Spacer(1, 12))

    # --- Revenue Analysis (Updated Section) ---
    story.append(Paragraph("Revenue Analysis", styles["Heading2"]))
    
    # Create revenue table with columns matching the Hardwell document format
    revenue_data = [['Revenue Source', 'T-12 Total', 'T-12 Per Unit', 'T-5 Total', 'T-5 Per Unit', 'UW Total', 'UW Per Unit']]

    # Extract revenue data from the parsed document
    revenue_sources = {
        'Rental Income': {
            't12_total': safe_get(data, ['revenue', 'rental_income', 't12_total'], safe_get(data, 'rental_income_t12', 1512177)),
            't12_per_unit': safe_get(data, ['revenue', 'rental_income', 't12_per_unit'], 17583),
            't5_total': safe_get(data, ['revenue', 'rental_income', 't5_total'], safe_get(data, 'rental_income_t5', 654035)),
            't5_per_unit': safe_get(data, ['revenue', 'rental_income', 't5_per_unit'], 18252),
            'uw_total': safe_get(data, ['revenue', 'rental_income', 'uw_total'], safe_get(data, 'rental_income_uw', 1615680)),
            'uw_per_unit': safe_get(data, ['revenue', 'rental_income', 'uw_per_unit'], 18787),
        },
        'Admin Income': {
            't12_total': safe_get(data, ['revenue', 'admin_income', 't12_total'], safe_get(data, 'admin_income_t12', 18400)),
            't12_per_unit': safe_get(data, ['revenue', 'admin_income', 't12_per_unit'], 214),
            't5_total': safe_get(data, ['revenue', 'admin_income', 't5_total'], safe_get(data, 'admin_income_t5', 5650)),
            't5_per_unit': safe_get(data, ['revenue', 'admin_income', 't5_per_unit'], 158),
            'uw_total': safe_get(data, ['revenue', 'admin_income', 'uw_total'], safe_get(data, 'admin_income_uw', 13560)),
            'uw_per_unit': safe_get(data, ['revenue', 'admin_income', 'uw_per_unit'], 158),
        },
        'Laundry': {
            't12_total': safe_get(data, ['revenue', 'laundry', 't12_total'], safe_get(data, 'laundry_t12', 15493)),
            't12_per_unit': safe_get(data, ['revenue', 'laundry', 't12_per_unit'], 180),
            't5_total': safe_get(data, ['revenue', 'laundry', 't5_total'], safe_get(data, 'laundry_t5', 6299)),
            't5_per_unit': safe_get(data, ['revenue', 'laundry', 't5_per_unit'], 176),
            'uw_total': safe_get(data, ['revenue', 'laundry', 'uw_total'], safe_get(data, 'laundry_uw', 15118)),
            'uw_per_unit': safe_get(data, ['revenue', 'laundry', 'uw_per_unit'], 176),
        },
        'RUBS': {
            't12_total': safe_get(data, ['revenue', 'rubs', 't12_total'], safe_get(data, 'rubs_t12', 94125)),
            't12_per_unit': safe_get(data, ['revenue', 'rubs', 't12_per_unit'], 1094),
            't5_total': safe_get(data, ['revenue', 'rubs', 't5_total'], safe_get(data, 'rubs_t5', 40125)),
            't5_per_unit': safe_get(data, ['revenue', 'rubs', 't5_per_unit'], 1120),
            'uw_total': safe_get(data, ['revenue', 'rubs', 'uw_total'], safe_get(data, 'rubs_uw', 96300)),
            'uw_per_unit': safe_get(data, ['revenue', 'rubs', 'uw_per_unit'], 1120),
        }
    }

    # Initialize totals for calculation
    total_t12_total = 0
    total_t12_per_unit = 0
    total_t5_total = 0
    total_t5_per_unit = 0
    total_uw_total = 0
    total_uw_per_unit = 0

    # Add revenue data to table and calculate totals
    for source_name, values in revenue_sources.items():
        # Convert values to float for calculation
        t12_total = safe_float(values['t12_total'])
        t12_per_unit = safe_float(values['t12_per_unit'])
        t5_total = safe_float(values['t5_total'])
        t5_per_unit = safe_float(values['t5_per_unit'])
        uw_total = safe_float(values['uw_total'])
        uw_per_unit = safe_float(values['uw_per_unit'])
        
        # Add to totals
        total_t12_total += t12_total
        total_t12_per_unit += t12_per_unit
        total_t5_total += t5_total
        total_t5_per_unit += t5_per_unit
        total_uw_total += uw_total
        total_uw_per_unit += uw_per_unit
        
        # Add row to table
        revenue_data.append([
            clean_text(source_name),
            format_currency(t12_total),
            format_currency(t12_per_unit),
            format_currency(t5_total),
            format_currency(t5_per_unit),
            format_currency(uw_total),
            format_currency(uw_per_unit)
        ])

    # Add Total Potential Gross Income row (highlighted)
    revenue_data.append([
        clean_text("Total Potential Gross Income"),
        format_currency(total_t12_total),
        format_currency(total_t12_per_unit),
        format_currency(total_t5_total),
        format_currency(total_t5_per_unit),
        format_currency(total_uw_total),
        format_currency(total_uw_per_unit)
    ])

    # Add Vacancy & Collection row
    vacancy_t12 = safe_get(data, ['revenue', 'vacancy_collection_loss', 't12_total'], 0)
    vacancy_t5 = safe_get(data, ['revenue', 'vacancy_collection_loss', 't5_total'], 0)
    vacancy_uw = safe_get(data, ['revenue', 'vacancy_collection_loss', 'uw_total'], 87033)
    
    vacancy_t12_per_unit = safe_float(vacancy_t12) / 86 if 86 > 0 else 0
    vacancy_t5_per_unit = safe_float(vacancy_t5) / 86 if 86 > 0 else 0
    vacancy_uw_per_unit = safe_float(vacancy_uw) / 86 if 86 > 0 else 0

    revenue_data.append([
        clean_text("Less: Vacancy & Collection Loss"),
        format_currency(vacancy_t12),
        format_currency(vacancy_t12_per_unit),
        format_currency(vacancy_t5),
        format_currency(vacancy_t5_per_unit),
        format_currency(vacancy_uw),
        format_currency(vacancy_uw_per_unit)
    ])

    # Add Adjustments/concessions row
    adjustments_t12 = safe_get(data, ['revenue', 'adjustments_concessions', 't12_total'], 0)
    adjustments_t5 = safe_get(data, ['revenue', 'adjustments_concessions', 't5_total'], 0)
    adjustments_uw = safe_get(data, ['revenue', 'adjustments_concessions', 'uw_total'], 0)
    
    adjustments_t12_per_unit = safe_float(adjustments_t12) / 86 if 86 > 0 else 0
    adjustments_t5_per_unit = safe_float(adjustments_t5) / 86 if 86 > 0 else 0
    adjustments_uw_per_unit = safe_float(adjustments_uw) / 86 if 86 > 0 else 0

    revenue_data.append([
        clean_text("Less: Adjustments/concessions"),
        format_currency(adjustments_t12),
        format_currency(adjustments_t12_per_unit),
        format_currency(adjustments_t5),
        format_currency(adjustments_t5_per_unit),
        format_currency(adjustments_uw),
        format_currency(adjustments_uw_per_unit)
    ])

    # Calculate Effective Gross Income
    egi_t12 = total_t12_total - safe_float(vacancy_t12) - safe_float(adjustments_t12)
    egi_t5 = total_t5_total - safe_float(vacancy_t5) - safe_float(adjustments_t5)
    egi_uw = total_uw_total - safe_float(vacancy_uw) - safe_float(adjustments_uw)
    
    egi_t12_per_unit = egi_t12 / 86 if 86 > 0 else 0
    egi_t5_per_unit = egi_t5 / 86 if 86 > 0 else 0
    egi_uw_per_unit = egi_uw / 86 if 86 > 0 else 0

    # Add Total Effective Gross Income row (highlighted)
    revenue_data.append([
        clean_text("Total Effective Gross Income"),
        format_currency(egi_t12),
        format_currency(egi_t12_per_unit),
        format_currency(egi_t5),
        format_currency(egi_t5_per_unit),
        format_currency(egi_uw),
        format_currency(egi_uw_per_unit)
    ])

    # Create table with adjusted column widths
    col_widths = [2*inch, 0.8*inch, 0.8*inch, 0.8*inch, 0.8*inch, 0.8*inch, 0.8*inch]
    
    revenue_table = Table(revenue_data, colWidths=col_widths)
    revenue_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('ALIGN', (0, 0), (0, -1), 'LEFT'),  # Left align first column
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 7),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('BACKGROUND', (0, -6), (-1, -6), colors.lightblue),  # Highlight PGI row
        ('BACKGROUND', (0, -1), (-1, -1), colors.lightblue),  # Highlight EGI row
        ('FONTNAME', (0, -6), (-1, -6), 'Helvetica-Bold'),    # Bold PGI row
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),    # Bold EGI row
    ]))
    story.append(revenue_table)
    story.append(Spacer(1, 12))

    # --- Unit Mix Analysis (Separate section for rent roll data) ---
    story.append(Paragraph("Unit Mix Analysis", styles["Heading2"]))
    unit_mix_data = [['Unit Type', 'Count', 'Avg Rent', 'Avg PSF', 'Underpriced Units']]

    rent_analysis = safe_get(data, ['rent_analysis', 'unit_types'], {})
    if isinstance(rent_analysis, dict) and rent_analysis:
        for unit_type, stats in rent_analysis.items():
            if isinstance(stats, dict):
                unit_mix_data.append([
                    clean_text(unit_type),
                    clean_text(stats.get('count', 0)),
                    clean_text(f"${stats.get('avg_rent', 0):,.2f}"),
                    clean_text(f"${stats.get('avg_psf', 0):,.4f}"),
                    clean_text(stats.get('underpriced_count', 0))
                ])
    else:
        # Default values from your example
        unit_mix_data.extend([
            ["2 Bed / 1.5 Bath", "70", "$1,650.00", "$1.3895", "5"],
            ["3 Bed / 1.5 Bath", "3", "$1,795.00", "$0.9945", "0"]
        ])

    unit_mix_table = Table(unit_mix_data)
    unit_mix_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
    ]))
    story.append(unit_mix_table)
    story.append(Spacer(1, 12))

    # --- Expense Breakdown ---
    story.append(Paragraph("Expense Breakdown", styles["Heading2"]))
    expense_data = [['Category', 'Actual', 'Adjusted', 'Notes']]
    expense_categories = [
        ('Property Taxes', 'actual_taxes', 'adjusted_taxes', '+7.5% for refinance'),
        ('Insurance', 'actual_insurance', 'adjusted_insurance', '+5% adjustment'),
        ('Repairs & Maintenance', 'actual_repairs', 'adjusted_repairs', '$700/unit minimum'),
        ('Management Fee', 'actual_management', 'adjusted_management', '3.5% of gross income'),
        ('Utilities', 'actual_utilities', 'adjusted_utilities', '+2% adjustment'),
        ('Replacement Reserves', 'actual_reserves', 'adjusted_reserves', '$250/unit')
    ]
    for category, actual_key, adjusted_key, note in expense_categories:
        actual_val = safe_get(data, actual_key, 0)
        adjusted_val = safe_get(data, adjusted_key, actual_val)
        expense_data.append([
            clean_text(category),
            clean_text(f"{format_currency(actual_val)}"),
            clean_text(f"{format_currency(adjusted_val)}"),
            clean_text(note)
        ])

    expense_table = Table(expense_data, colWidths=[1.5*inch, 1*inch, 1*inch, 2*inch])
    expense_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 0), (2, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
    ]))
    story.append(expense_table)
    story.append(Spacer(1, 12))

    # --- Loan Options ---
    story.append(Paragraph("Loan Options", styles["Heading2"]))
    loan_data = [['Loan Type', 'Max LTV', 'Min DSCR', 'Rate', 'Max Loan Amount']]
    loan_options = safe_get(data, 'loan_options', {})

    if isinstance(loan_options, dict) and loan_options:
        for loan_type, details in loan_options.items():
            if isinstance(details, dict):
                loan_data.append([
                    clean_text(loan_type),
                    clean_text(f"{details.get('Max LTV', 0)*100:.0f}%"),
                    clean_text(f"{details.get('Min DSCR', 0):.2f}x"),
                    clean_text(f"{details.get('Rate', 0)*100:.2f}%"),
                    clean_text(f"${details.get('Max Loan', 0):,.2f}")
                ])
    else:
        loan_data.extend([
            ['FANNIE/FREDDIE', '75%', '1.25x', '4.50%', '$5,925,000.00'],
            ['CMBS', '75%', '1.25x', '5.50%', '$5,925,000.00'],
            ['DEBT FUND', '80%', '0.95x', '6.50%', '$9,728,000.00']
        ])

    loan_table = Table(loan_data)
    loan_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
    ]))
    story.append(loan_table)
    story.append(Spacer(1, 12))

    # --- Notes ---
    story.append(Paragraph("Underwriting Notes", styles["Heading2"]))
    notes = [
        "1. All expenses adjusted according to underwriting standards",
        "2. Property taxes increased by 7.5% for refinance scenario",
        "3. Insurance premiums increased by 5%",
        "4. Repairs & Maintenance adjusted to meet minimum thresholds",
        "5. Management fee calculated at tiered percentage of gross income",
        "6. Replacement reserves included at $250/unit",
        "7. Vacancy calculated at 5% of Gross Potential Income"
    ]
    for note in notes:
        story.append(Paragraph(clean_text(note), styles['Normal']))
        story.append(Spacer(1, 4))

    # --- Build PDF ---
    doc = SimpleDocTemplate(filepath, pagesize=letter)
    doc.build(story)

    return filename


def generate_pdf_report(data: Dict[str, Any]) -> str:
    """
    Generate PDF report safely, always returning a filename.
    Falls back to a basic text file if PDF creation fails.
    """
    try:
        filename = generate_safe_pdf_report(data)
        logger.info(f"PDF report generated successfully: {filename}")
        return filename
    except Exception as e:
        logger.error(f"PDF generation failed: {str(e)}")
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"basic_report_{timestamp}.txt"
        output_dir = os.environ.get('OUTPUT_FOLDER', 'outputs')
        os.makedirs(output_dir, exist_ok=True)
        filepath = os.path.join(output_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write("UNDERWRITING REPORT\n")
            f.write("==================\n\n")
            f.write("Note: This is a basic report due to processing limitations.\n\n")
            for key, value in data.items():
                f.write(f"{key}: {value}\n")
        return filename