# app/utils/t12_processor.py
"""
Updated T12 processor with safe error handling
"""
import logging
from typing import Dict, Any, Optional
from .safe_processor import safe_process_t12

logger = logging.getLogger(__name__)

def process_t12(filepath: Optional[str] = None) -> Dict[str, Any]:
    """
    Process T12 file safely, returning extracted data or empty dict
    """
    if not filepath:
        logger.info("No T12 file provided")
        return {}
        
    try:
        data = safe_process_t12(filepath)
        logger.info(f"T12 processing completed. Extracted {len(data)} data points.")
        return data
    except Exception as e:
        logger.error(f"T12 processing failed: {str(e)}")
        return {}