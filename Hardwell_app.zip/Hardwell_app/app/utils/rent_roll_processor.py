# app/utils/rent_roll_processor.py
"""
Updated rent roll processor with safe error handling
"""
import logging
from typing import Dict, Any, Optional
from .safe_processor import safe_process_rent_roll

logger = logging.getLogger(__name__)

def process_rent_roll(filepath: Optional[str] = None) -> Dict[str, Any]:
    """
    Process rent roll file safely, returning extracted data or empty dict
    """
    if not filepath:
        logger.info("No rent roll file provided")
        return {}
        
    try:
        data = safe_process_rent_roll(filepath)
        logger.info(f"Rent roll processing completed. Extracted {len(data)} data points.")
        return data
    except Exception as e:
        logger.error(f"Rent roll processing failed: {str(e)}")
        return {}