from flask import Blueprint, render_template, request, redirect, url_for, send_from_directory, current_app, flash
import os
from werkzeug.utils import secure_filename
from app.utils.rent_roll_processor import process_rent_roll
from app.utils.t12_processor import process_t12
from app.utils.calculator import calculate_underwriting
from app.utils.pdf_generator import generate_pdf_report

bp = Blueprint('main', __name__)

def safe_float(value, default=0.0):
    """Safely convert value to float, return default if conversion fails"""
    try:
        return float(value) if value and str(value).strip() else default
    except (ValueError, TypeError):
        return default

def safe_int(value, default=0):
    """Safely convert value to int, return default if conversion fails"""
    try:
        return int(value) if value and str(value).strip() else default
    except (ValueError, TypeError):
        return default

def extract_form_inputs(form_data):
    """Extract and validate form inputs including Hardwell UW format"""
    return {
        'property_name': form_data.get('property_name', '').strip(),
        'property_address': form_data.get('property_address', '').strip(),
        'total_units': safe_int(form_data.get('total_units')),
        'occupied_units': safe_int(form_data.get('occupied_units')),
        
        # Hardwell UW Revenue Format
        'rental_income': safe_float(form_data.get('rental_income')),
        'admin_income': safe_float(form_data.get('admin_income')),
        'laundry_income': safe_float(form_data.get('laundry_income')),
        'rubs_income': safe_float(form_data.get('rubs_income')),
        'gross_potential_rent': safe_float(form_data.get('gross_potential_rent')),
        'effective_gross_income': safe_float(form_data.get('effective_gross_income')),
        
        # Financial data
        'total_operating_expenses': safe_float(form_data.get('total_operating_expenses')),
        'net_operating_income': safe_float(form_data.get('net_operating_income')),
        'purchase_price': safe_float(form_data.get('purchase_price')),
        'vacancy_loss': safe_float(form_data.get('vacancy_loss')),
        
        # Underwriting assumptions
        'cap_rate': safe_float(form_data.get('cap_rate')),
        'vacancy_rate': safe_float(form_data.get('vacancy_rate')),
        'annual_rent_growth': safe_float(form_data.get('annual_rent_growth')),
        'expense_growth': safe_float(form_data.get('expense_growth'))
    }

def process_uploaded_files(request):
    """Process uploaded files and extract data safely"""
    rent_roll_data = {}
    t12_data = {}
    
    # Process rent roll file
    if 'rent_roll' in request.files and request.files['rent_roll'].filename:
        try:
            rent_roll_file = request.files['rent_roll']
            if rent_roll_file and rent_roll_file.filename != '':
                filename = secure_filename(rent_roll_file.filename)
                filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                rent_roll_file.save(filepath)
                rent_roll_data = process_rent_roll(filepath)
                current_app.logger.info(f"Rent roll processed successfully: {filename}")
        except Exception as e:
            current_app.logger.warning(f"Rent roll processing failed: {str(e)}")
            flash(f'Rent roll processing warning: {str(e)}', 'warning')
    
    # Process T12 file
    if 't12' in request.files and request.files['t12'].filename:
        try:
            t12_file = request.files['t12']
            if t12_file and t12_file.filename != '':
                filename = secure_filename(t12_file.filename)
                filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                t12_file.save(filepath)
                t12_data = process_t12(filepath)
                current_app.logger.info(f"T12 processed successfully: {filename}")
        except Exception as e:
            current_app.logger.warning(f"T12 processing failed: {str(e)}")
            flash(f'T12 processing warning: {str(e)}', 'warning')
    
    return rent_roll_data, t12_data

def merge_data_with_inputs(extracted_data, form_inputs, data_type=""):
    """Merge extracted data with form inputs, prioritizing form inputs"""
    merged_data = extracted_data.copy() if extracted_data else {}
    
    # Override with form inputs if provided
    for key, value in form_inputs.items():
        if value:  # Only override if form input has a value
            merged_data[key] = value
            
    return merged_data

def create_default_data(form_inputs):
    """Create default data structure when no files are processed"""
    # Calculate derived values from Hardwell UW format
    rental_income = form_inputs.get('rental_income', 1512177)
    admin_income = form_inputs.get('admin_income', 18400)
    laundry_income = form_inputs.get('laundry_income', 15493)
    rubs_income = form_inputs.get('rubs_income', 94125)
    
    # Calculate totals
    total_other_income = admin_income + laundry_income + rubs_income
    total_revenue = rental_income + total_other_income
    
    default_data = {
        'property_name': form_inputs.get('property_name', 'Bolden Heights'),
        'property_address': form_inputs.get('property_address', '3350 Mount Gilead Rd, Atlanta, GA 30311'),
        'total_units': form_inputs.get('total_units', 86),
        'occupied_units': form_inputs.get('occupied_units', 84),
        
        # Hardwell UW Revenue Format
        'rental_income': rental_income,
        'admin_income': admin_income,
        'laundry_income': laundry_income,
        'rubs_income': rubs_income,
        'gross_potential_rent': form_inputs.get('gross_potential_rent', 1640195),
        'effective_gross_income': form_inputs.get('effective_gross_income', total_revenue),
        
        # Calculated fields for backward compatibility
        'actual_rental_income': rental_income,
        'other_income': total_other_income,
        'total_revenue': total_revenue,
        
        # Financial data
        'total_operating_expenses': form_inputs.get('total_operating_expenses', 281553),
        'net_operating_income': form_inputs.get('net_operating_income', total_revenue - form_inputs.get('total_operating_expenses', 281553)),
        'purchase_price': form_inputs.get('purchase_price', 15500000),
        'vacancy_loss': form_inputs.get('vacancy_loss', 0),
        
        # Underwriting assumptions
        'cap_rate': form_inputs.get('cap_rate', 7.9),
        'vacancy_rate': form_inputs.get('vacancy_rate', 5.0),
        'annual_rent_growth': form_inputs.get('annual_rent_growth', 3.0),
        'expense_growth': form_inputs.get('expense_growth', 2.5),
        
        # Additional calculated fields
        'occupancy_rate': (form_inputs.get('occupied_units', 84) / form_inputs.get('total_units', 86)) * 100 if form_inputs.get('total_units', 86) > 0 else 97.7,
        'rent_per_unit': rental_income / form_inputs.get('total_units', 86) if form_inputs.get('total_units', 86) > 0 else 17583,
    }
    
    # Calculate derived fields if not provided
    if not form_inputs.get('net_operating_income'):
        default_data['net_operating_income'] = total_revenue - default_data['total_operating_expenses']
    
    if not form_inputs.get('cap_rate') and default_data['net_operating_income'] and default_data['purchase_price']:
        default_data['cap_rate'] = (default_data['net_operating_income'] / default_data['purchase_price']) * 100
    
    return default_data

@bp.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            # Extract form inputs first
            form_inputs = extract_form_inputs(request.form)
            current_app.logger.info(f"Form inputs extracted: {form_inputs}")
            
            # Process uploaded files (this won't fail even if processing fails)
            rent_roll_data, t12_data = process_uploaded_files(request)
            
            # Merge extracted data with form inputs (form inputs take priority)
            final_rent_roll_data = merge_data_with_inputs(rent_roll_data, form_inputs, "rent_roll")
            final_t12_data = merge_data_with_inputs(t12_data, form_inputs, "t12")
            
            # If no meaningful data was extracted and no form inputs provided, use defaults
            if not final_rent_roll_data and not final_t12_data and not any(form_inputs.values()):
                current_app.logger.info("No data extracted or provided, using defaults")
                combined_data = create_default_data({})
            else:
                # Combine all available data
                combined_data = {**final_rent_roll_data, **final_t12_data}
                
                # Fill in any missing critical fields with defaults
                if not combined_data:
                    combined_data = create_default_data(form_inputs)
                else:
                    # Ensure we have at least the basic structure
                    default_structure = create_default_data(form_inputs)
                    for key, default_value in default_structure.items():
                        if key not in combined_data or not combined_data[key]:
                            combined_data[key] = default_value
            
            current_app.logger.info(f"Final combined data keys: {list(combined_data.keys())}")
            
            # Generate underwriting analysis (this should never fail now)
            try:
                underwriting_data = calculate_underwriting(combined_data, combined_data)
            except Exception as e:
                current_app.logger.warning(f"Underwriting calculation failed, using basic calculations: {str(e)}")
                # Fallback to basic calculations
                underwriting_data = {
                    **combined_data,
                    'analysis_date': 'Generated from available data',
                    'total_return': combined_data.get('net_operating_income', 0),
                    'cash_flow': combined_data.get('net_operating_income', 0),
                    'calculated_cap_rate': combined_data.get('cap_rate', 0),
                }
            
            # Generate PDF report (this should always work)
            try:
                report_filename = generate_pdf_report(underwriting_data)
                flash('Report generated successfully!', 'success')
                return redirect(url_for('main.report', filename=report_filename))
            except Exception as e:
                # Final fallback - generate a basic report
                current_app.logger.error(f"PDF generation failed: {str(e)}")
                try:
                    report_filename = generate_basic_pdf_report(underwriting_data)
                    flash('Basic report generated (some features may be limited)', 'warning')
                    return redirect(url_for('main.report', filename=report_filename))
                except Exception as e2:
                    flash(f'Report generation failed: {str(e2)}', 'error')
                    return redirect(url_for('main.index'))
        
        except Exception as e:
            current_app.logger.error(f'System Error: {str(e)}', exc_info=True)
            flash(f'System Error: {str(e)}', 'error')
    
    return render_template('index.html')

def generate_basic_pdf_report(data):
    """Generate a basic PDF report as fallback"""
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.pdfgen import canvas
        from datetime import datetime
        
        filename = f"basic_underwriting_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        filepath = os.path.join(current_app.config['OUTPUT_FOLDER'], filename)
        
        c = canvas.Canvas(filepath, pagesize=letter)
        width, height = letter
        
        # Title
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, height - 50, "Underwriting Report")
        
        # Property info
        y_position = height - 100
        c.setFont("Helvetica", 12)
        
        report_data = [
            f"Property: {data.get('property_name', 'N/A')}",
            f"Address: {data.get('property_address', 'N/A')}",
            f"Total Units: {data.get('total_units', 'N/A')}",
            f"Occupied Units: {data.get('occupied_units', 'N/A')}",
            f"Gross Potential Rent: ${data.get('gross_potential_rent', 0):,.2f}",
            f"Net Operating Income: ${data.get('net_operating_income', 0):,.2f}",
            f"Purchase Price: ${data.get('purchase_price', 0):,.2f}",
            f"Cap Rate: {data.get('cap_rate', 0):.2f}%",
        ]
        
        for line in report_data:
            c.drawString(50, y_position, line)
            y_position -= 20
        
        c.save()
        return filename
        
    except Exception as e:
        current_app.logger.error(f"Basic PDF generation failed: {str(e)}")
        raise

@bp.route('/report/<filename>')
def report(filename):
    return render_template('report.html', filename=filename)

@bp.route('/download/<filename>')
def download(filename):
    return send_from_directory(current_app.config['OUTPUT_FOLDER'], filename, as_attachment=True)