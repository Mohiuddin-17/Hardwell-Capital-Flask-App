----- HARDWELL CAPITAL AUTOMATION FLASK APP -----

- In order to run the program via Vscode or cmd prompt you need python installed, along with the libraries mentioned in the requirement.txt. 

- After all the installation a simple command python run.py in the terminal or cmd prompt will run the app. The application will host itself on local development server.

- There are two inputs one for Rent Roll other for T12. Both are able to take input in as CSV or PDF. If any PDF input is provided the script pdf_converter_t12.py is accessed by the program to convert it into CSV for further processing.

- pdf_generator.py holds the logic for creating the reports while rent_roll.py & t12_processor.py holds logic for respective document processing.

- test_script.py an additional script which is used for debugging in the entire framework.