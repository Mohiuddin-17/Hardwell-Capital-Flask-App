import os
import pandas as pd
from app.utils.rent_roll_processor import process_rent_roll
from app.utils.t12_processor import process_t12
from app.utils.calculator import calculate_underwriting
from app.utils.pdf_generator import generate_pdf_report

# Set up test environment
os.makedirs('test_uploads', exist_ok=True)
os.makedirs('test_outputs', exist_ok=True)

# In your test script
try:
    rr = process_rent_roll()
    t12 = process_t12()
    report = calculate_underwriting(rr, t12)
    print("Validation passed. Sample data:", report['income']['gross_potential_income'])
except Exception as e:
    print("VALIDATION FAILED:", str(e))

# Test rent roll processing
print("Testing rent roll processing...")
rent_roll_data = process_rent_roll()
print("Rent roll processing completed successfully.")
print(f"Total units: {rent_roll_data['rent_analysis']['total_units']}")
print(f"Total annual rent: ${rent_roll_data['rent_analysis']['total_annual_rent']:,.2f}")

# Test T12 processing
print("\nTesting T12 processing...")
t12_data = process_t12()
print("T12 processing completed successfully.")
print(f"Annual NOI: ${t12_data['annual_totals']['NET OPERATING INCOME']:,.2f}")

# Test underwriting calculation
print("\nTesting underwriting calculation...")
underwriting_data = calculate_underwriting(rent_roll_data, t12_data)
print("Underwriting calculation completed successfully.")
print(f"Property value: ${underwriting_data['property_value']:,.2f}")

# Test PDF generation
print("\nTesting PDF generation...")
filename = generate_pdf_report(underwriting_data)
print(f"PDF report generated: {filename}")

print("\nAll tests completed successfully.")